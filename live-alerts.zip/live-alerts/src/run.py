"""
Single-shot alert check, designed to run on a 5-minute cron via GitHub Actions.

Reads dedup state from state.json, runs all sources once, sends pushes for
new items, writes state.json back. Exits cleanly.
"""
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

# Make sibling modules importable
sys.path.insert(0, str(Path(__file__).parent))

from sources import (
    fetch_market_news,
    fetch_economic_news,
    fetch_trump_posts,
    fetch_hormuz_news,
    fetch_maritime_data,
)
from notifier import send_push

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("alerts")

# State file lives at the repo root (parent of src/)
STATE_FILE = Path(__file__).parent.parent / "state.json"

# Keep at most this many IDs in state to prevent unbounded growth
MAX_STATE_SIZE = 8000

# If a single cycle wants to send more than this, something is wrong
# (feed misbehaving, keyword too broad, etc) — send a summary instead
MAX_NOTIFICATIONS_PER_RUN = 25


def load_state() -> dict:
    if not STATE_FILE.exists():
        return {"first_run": True, "seen": []}
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception as e:
        log.warning(f"State file corrupt, starting fresh: {e}")
        return {"first_run": True, "seen": []}


def save_state(state: dict) -> None:
    # Trim to most recent N IDs (state["seen"] is appended in chronological order)
    if len(state["seen"]) > MAX_STATE_SIZE:
        state["seen"] = state["seen"][-MAX_STATE_SIZE:]
    STATE_FILE.write_text(json.dumps(state, indent=2))


async def main() -> int:
    topic = os.environ.get("NTFY_TOPIC", "").strip()
    if not topic:
        log.error("NTFY_TOPIC environment variable is empty or missing.")
        log.error("Add it as a repository secret in GitHub Settings → Secrets and variables → Actions.")
        return 1

    config = {
        "ntfy": {
            "topic": topic,
            "server": os.environ.get("NTFY_SERVER", "https://ntfy.sh"),
        },
        # Recency windows. Items older than this are ignored.
        # 1 hour gives buffer in case a run was delayed.
        "market_max_age_hours": 1.0,
        "economic_max_age_hours": 6.0,
        "trump_max_age_hours": 1.5,
        "hormuz_max_age_hours": 4.0,
        # Maritime API requires a paid key — see README
        "maritime": {"enabled": False},
    }

    state = load_state()
    seen = set(state.get("seen", []))
    is_first_run = state.get("first_run", True)

    fetchers = [
        ("market", fetch_market_news),
        ("economic", fetch_economic_news),
        ("trump", fetch_trump_posts),
        ("hormuz", fetch_hormuz_news),
        ("maritime", fetch_maritime_data),
    ]

    new_items: list[tuple[str, dict]] = []
    seen_order: list[str] = list(state.get("seen", []))

    for source_name, fn in fetchers:
        try:
            items = await fn(config)
        except Exception as e:
            log.error(f"[{source_name}] fetch failed: {e}")
            continue

        for item in items:
            if item["id"] in seen:
                continue
            new_items.append((source_name, item))
            seen.add(item["id"])
            seen_order.append(item["id"])

    log.info(f"Found {len(new_items)} new items (first_run={is_first_run})")

    if is_first_run:
        # Don't flood the user with current news on first run.
        # Just seed state and send a confirmation ping.
        try:
            send_push(
                topic=topic,
                title="✅ Live alerts online",
                message=(
                    f"Setup complete. Tracking {len(new_items)} current items. "
                    "You'll only get alerts for NEW items from now on."
                ),
                priority=3,
                tags=["white_check_mark"],
            )
            log.info("Sent startup confirmation.")
        except Exception as e:
            log.warning(f"Startup ping failed: {e}")
        state["first_run"] = False

    elif len(new_items) > MAX_NOTIFICATIONS_PER_RUN:
        # Probably something wrong — feed flood, keyword too broad, etc.
        # Send a summary instead of spamming the user.
        log.warning(
            f"Suppressing {len(new_items)} alerts in one cycle (exceeds cap). "
            "Sending summary instead."
        )
        by_source: dict[str, int] = {}
        for src, _ in new_items:
            by_source[src] = by_source.get(src, 0) + 1
        breakdown = ", ".join(f"{k}: {v}" for k, v in by_source.items())
        try:
            send_push(
                topic=topic,
                title="⚠️ Alert flood suppressed",
                message=f"{len(new_items)} items in one cycle. Breakdown: {breakdown}",
                priority=3,
            )
        except Exception as e:
            log.warning(f"Flood notice failed: {e}")

    else:
        for source_name, item in new_items:
            try:
                send_push(
                    topic=topic,
                    title=item["title"],
                    message=item["message"],
                    url=item.get("url"),
                    priority=item.get("priority", 3),
                    tags=[source_name] + item.get("tags", []),
                )
                log.info(f"[{source_name}] sent: {item['title']}")
            except Exception as e:
                log.error(f"[{source_name}] push failed: {e}")

    state["seen"] = seen_order
    save_state(state)
    log.info(f"State saved with {len(seen_order)} tracked IDs.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
