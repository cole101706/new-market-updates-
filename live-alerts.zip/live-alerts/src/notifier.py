"""Push notifications via ntfy.sh — free, no account required."""
import httpx


def send_push(
    topic: str,
    title: str,
    message: str,
    server: str = "https://ntfy.sh",
    url: str | None = None,
    priority: int = 3,
    tags: list | None = None,
    timeout: int = 10,
) -> None:
    """
    Send a push notification via ntfy.

    Priority: 1=min, 2=low, 3=default, 4=high, 5=max (bypasses Do Not Disturb).
    """
    payload = {
        "topic": topic,
        "title": title,
        "message": message,
        "priority": priority,
    }
    if url:
        payload["click"] = url
    if tags:
        payload["tags"] = tags

    r = httpx.post(server, json=payload, timeout=timeout)
    r.raise_for_status()
