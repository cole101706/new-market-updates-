# Live Alerts — Setup Guide

Push notifications to your phone for stock market news, Trump statements
about markets/Iran/war, Strait of Hormuz / Iran developments, and Fed/economic
data — running 24/7, **completely free**, with no server or coding required.

This guide assumes **zero technical background**. Every step is explained.
If you can sign up for accounts and click buttons, you can do this in **15 minutes**.

---

## How it works (1-minute overview)

1. You install a free app called **ntfy** on your phone. It receives notifications.
2. You upload these files to a free **GitHub** account.
3. GitHub runs a small program every 5 minutes that checks all the news sources
   and sends a push notification to your phone whenever something relevant appears.
4. That's it. It runs forever, free, with no maintenance.

**Recommendation: do this on a computer if possible.** It works on a phone,
but uploading files is easier on a computer.

---

## PART 1 — Install the notification app on your phone (2 minutes)

**Step 1.** Install **ntfy**:
- iPhone: https://apps.apple.com/us/app/ntfy/id1625396347
- Android: https://play.google.com/store/apps/details?id=io.heckel.ntfy

**Step 2.** Open ntfy. Tap the **+** button (top right on iOS, bottom right on Android).

**Step 3.** It asks for a "Topic name." This is a secret password that links
your phone to your alerts. Make up something **long and random** — at least
15 characters mixing letters and numbers. Examples:
- `cole-news-x7k2m9p4qz`
- `market-alerts-94kfj38dnz`
- `my-feed-q9p3m7x2bv`

**⚠️ Anyone who knows this name can send you spam or read your alerts.**
Don't use anything obvious like your name. Don't share it.

**Step 4.** Tap **Subscribe**. Save this topic name somewhere — you'll need
it again in Part 3.

**Step 5.** When iOS/Android asks if ntfy can send notifications, tap **Allow**.

✅ **Test it:** Open a web browser and visit:
`https://ntfy.sh/YOUR-TOPIC-NAME-HERE`

(Replace with your actual topic name.) Type `test` in the message box on that
page and click Send. You should get a push notification on your phone within
seconds. If you do, ntfy is working. If not, double-check your topic name.

---

## PART 2 — Set up GitHub (5 minutes)

GitHub is a free service that will run your alert program 24/7.

**Step 6.** Go to https://github.com and click **Sign up**. Use any email.
Free plan is fine — no credit card needed.

**Step 7.** After signing up and verifying your email, click the **+** in the
top-right corner → **New repository**.

**Step 8.** Fill in the form:
- **Repository name:** anything you want, e.g. `my-alerts`
- **Visibility:** select **Private** ⚠️ (this is important — keeps your topic name secret)
- **Initialize this repository:** leave all checkboxes UNCHECKED
- Click the green **Create repository** button at the bottom

**Step 9.** You'll land on an empty repo page with setup instructions. Ignore
those. Look for the link **"uploading an existing file"** in the middle of the
page (it's underlined). Click it.

**Step 10.** A file upload page opens. **You need to upload all the files I
gave you.** The structure must be preserved:

```
my-alerts/
├── .github/
│   └── workflows/
│       └── alerts.yml
├── src/
│   ├── run.py
│   ├── sources.py
│   └── notifier.py
├── state.json
├── requirements.txt
├── .gitignore
└── README.md          ← this file
```

The easiest way: **drag the entire `live-alerts` folder** from your computer
onto the upload area. GitHub will preserve the folder structure.

If drag-and-drop doesn't preserve folders, use **"choose your files"** and
select all files at once. GitHub's web uploader supports nested folders this way.

**Step 11.** Scroll to the bottom. In the "Commit changes" box, leave the
default message and click the green **Commit changes** button.

✅ Your repo should now show all the files in their folders.

---

## PART 3 — Tell GitHub your topic name (1 minute)

**Step 12.** In your repo, click the **Settings** tab at the top.

**Step 13.** In the left sidebar, click **Secrets and variables** to expand it,
then click **Actions** underneath.

**Step 14.** Click the green **New repository secret** button.

**Step 15.** Fill in:
- **Name:** `NTFY_TOPIC` (exactly this, all caps, with the underscore)
- **Secret:** paste your topic name from Step 3 (e.g. `cole-news-x7k2m9p4qz`)

**Step 16.** Click **Add secret**.

---

## PART 4 — Turn it on (1 minute)

**Step 17.** Click the **Actions** tab at the top of your repo.

**Step 18.** GitHub may show a yellow banner asking about workflows. Click the
green **"I understand my workflows, go ahead and enable them"** button.

**Step 19.** In the left sidebar, click **Live Alerts**.

**Step 20.** On the right, click the **Run workflow** dropdown → **Run workflow**
button. This kicks off the first run manually so you don't have to wait 5 minutes.

**Step 21.** Wait ~30 seconds. Refresh the page. You should see a run with a
spinning yellow circle (running) which turns into a green checkmark (success).

**Step 22.** Within a minute, your phone should buzz with a notification:

> ✅ Live alerts online
> Setup complete. Tracking N current items. You'll only get alerts for NEW items from now on.

🎉 **You're done.** From this moment on, GitHub will automatically check
every 5 minutes, forever, and notify you of new market news / Trump statements
/ Iran developments / Fed releases as they happen.

---

## What you'll see

Each notification looks like:

> 📈 **CNBC Markets**
> Fed signals two more rate cuts this year as inflation cools

> 🔴 **Trump (Truth Social)**
> [his post text, when it touches markets/Iran/war]

> ⚓ **Reuters World**
> Iran threatens Strait of Hormuz closure after sanctions

> 🏛️ **Fed Press**
> Federal Reserve Board announces approval of...

The 🏛️ Fed/Treasury/BLS alerts come through at **maximum priority** —
they bypass Do Not Disturb mode because they move markets the moment they hit.

Tap any notification to open the article.

---

## Speed expectations — be honest

| Source                           | Typical lag from publication |
|----------------------------------|------------------------------|
| Trump Truth Social posts         | 5–10 minutes                 |
| Major newswires (CNBC, Reuters)  | 5–10 minutes                 |
| Fed/BLS official releases        | 5–10 minutes                 |
| Strait of Hormuz news            | 5–10 minutes                 |

This is because GitHub Actions runs every 5 minutes. The RSS feeds themselves
update within seconds of the source publishing.

**If you need sub-second alerts** for active day trading, you need a paid
service like Benzinga Pro (~$177/mo) or a Bloomberg Terminal. This free system
is built for swing trades, position sizing decisions, and not missing macro
events while you're away from screens.

---

## Common problems

**"I'm not getting any notifications after the first one."**

Open ntfy on your phone. Make sure your topic is still subscribed and shows
"Connected" status. If it shows disconnected, tap it and re-subscribe. Also
make sure ntfy has notification permission (iOS Settings → Notifications →
ntfy → Allow Notifications ON).

**"The Actions tab shows red X marks."**

Click the failed run to see the error. Most common cause: `NTFY_TOPIC` secret
wasn't added correctly (Part 3). Double-check that the secret name is exactly
`NTFY_TOPIC` (uppercase, with underscore) and the value is your topic.

**"I'm getting too many notifications."**

Edit `src/sources.py`. You can:
- Remove feeds from `MARKET_FEEDS` (e.g., delete the lines for sources you don't want)
- Make `TRUMP_RELEVANT_KW` more restrictive (require more specific keywords)
- Lower `market_max_age_hours` in `src/run.py` to 0.5 to only catch fresh items

**"Trump posts aren't coming through."**

The `trumpstruth.org` mirror sometimes has outages. The news fetchers will
still catch his statements when major outlets cover them. To verify: visit
`https://trumpstruth.org/feed` in a browser and confirm it loads.

**"GitHub Actions isn't running every 5 minutes."**

GitHub's cron is best-effort. During high load, it can be delayed up to 15–20
minutes. This is rare but does happen. There's no fix on the free tier — for
guaranteed timing you'd need a paid host.

---

## Optional: add Strait of Hormuz vessel traffic

Real-time AIS (vessel tracking) data isn't free. The cheapest realistic option
is **Datalastic** (~$50/mo, https://datalastic.com). Once you have a key,
edit `src/run.py` and change:

```python
"maritime": {"enabled": False},
```

to:

```python
"maritime": {
    "enabled": True,
    "provider": "datalastic",
    "api_key": "your-key-here",
},
```

(Better yet: store the key as a GitHub secret like `DATALASTIC_KEY` and read
it from `os.environ`. Same pattern as `NTFY_TOPIC`.)

The current implementation reports total vessel count and tanker count in
the strait once per hour. Edit `fetch_maritime_data` in `src/sources.py` to
alert on changes (sudden drop = potential blockade signal).

---

## Cost summary

| Item                       | Cost      |
|----------------------------|-----------|
| ntfy app + service         | **Free**  |
| GitHub account             | **Free**  |
| GitHub Actions (private repo) | **Free** (2,000 min/month free; this uses ~150) |
| Optional: vessel tracking  | ~$50/mo (Datalastic) |

Total: **$0/month** for the core feature set.

---

## What if I want to change things later?

Everything is just code. To change anything:

1. Open your GitHub repo in a browser
2. Click on the file (e.g., `src/sources.py`)
3. Click the pencil icon (✏️) at the top right
4. Edit
5. Click "Commit changes" at the bottom

Common edits:
- **Add a new RSS feed:** Add a line to `MARKET_FEEDS` in `src/sources.py`
- **Filter out a topic:** Add a check like `if "crypto" in title.lower(): continue`
  in the relevant fetcher
- **Change polling frequency:** Edit `cron: '*/5 * * * *'` in
  `.github/workflows/alerts.yml` (5 minutes is the GitHub minimum)
- **Pause alerts:** Settings → Actions → General → Disable Actions

Ask me to help with any specific change — share what you want and I'll give
you the exact edit.
